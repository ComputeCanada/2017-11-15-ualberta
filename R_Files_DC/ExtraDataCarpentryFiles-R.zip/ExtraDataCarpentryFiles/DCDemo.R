# Data Carpentry Demo

#### Climate Data ####

library(tidyverse)
library(reshape2)
library(rebus)
library(zoo)
library(stingr)
library(lubridate)
library(readr)
library(stringr)

# temp <- tempfile()
# download.file("ftp://ccrp.tor.ec.gc.ca/pub/EC_data/AHCCD_daily/Homog_daily_mean_temp_v2016.zip",temp)
# big_listA <- lapply(unzip(temp), read_csv)
# lapply(unzip("path/test2.zip"), read.csv)
# unlink(temp)

file_list <- list.files("/Users/brian/Dropbox/db documents/HomeR Practice/DataCarpentry/Homog_daily_mean_temp_v2016/", full.names = TRUE)
big_listA <- lapply(file_list, read_csv)

yy <- unlist(sapply(big_listA, "[[", 2))
yyExt <- yy[!is.na(yy)]
yyExt <- str_replace_all(yyExt, pattern = one_or_more(SPC), replacement = "_")
yy2 <- unlist(sapply(big_listA, "[[", 3))
yy2Ext <- str_extract(yy2, pattern = one_or_more(WRD))
yyExt <- yyExt[!is.na(yyExt)]
yy2Ext <- yy2Ext[!is.na(yy2Ext)]
yyNames <- str_c(yyExt, yy2Ext, sep = "_")

zz <- unlist(sapply(big_listA, "[[", 1))

zzStart <- str_detect(zz, pattern = START %R% 'Year')
yearVec <- which(zzStart == TRUE)

locRep <- numeric()
for(i in 1:length(yearVec)) {
	locRep[i] <- (yearVec[i+1] - yearVec[i])
}
locRep[338] <- length(zz) - sum(locRep, na.rm = TRUE)
locVec <- rep(yyNames, times = locRep-2) # This will get appended to zz after some rows are deleted
# And after the NAs and characters are eliminated

zz <- zz[-c(yearVec, yearVec - 1, yearVec + 1)]
# zzTest <- zz[c(yearVec, yearVec - 1, yearVec + 1)]

# zzLeng <- str_length(zz)

zz <- gsub("a", " ", zz, fixed = TRUE) # Works

zz <- gsub("-9999.9M", replacement = "NA ", zz, fixed = TRUE)

zz <- str_c(locVec, zz, sep = " ")


CanCliNames <- c("location", "year", "month", paste("D", as.character(1:31), sep = "_"))

CanClimate <- colsplit(zz, one_or_more(SPC), names=CanCliNames)

object.size(CanClimate) # 101489224 bytes
CanClimate[,c(4:34)] <- apply(CanClimate[,c(4:34)], 2, as.numeric)
object.size(CanClimate) # 99400920 bytes # diff or 2088304

rm(list = setdiff(ls(), "CanClimate"))

CanClimate <- CanClimate %>% 
	gather(day, meanTemp, -c(location, year, month)) %>% 
	arrange(location, year, month)

CanClimateMM <- CanClimate %>% 
	group_by(location, year, month) %>% 
	summarise(monthMeanTemp = mean(meanTemp, na.rm = T)) %>% 
	mutate(date = paste(year, month, sep = "-" ))

CanClimateMM$date <- as.yearmon(CanClimateMM$date)


ggplot(subset(CanClimateMM, location %in% "VICTORIA_BC"), aes(date, monthMeanTemp, fill = location)) + geom_smooth(method = lm) # + geom_point()

ggplot(subset(CanClimateMM, location %in% "AGASSIZ_BC"), aes(date, monthMeanTemp, fill = location)) + geom_smooth(method = lm)

ggplot(subset(CanClimateMM, location %in% c("AGASSIZ_BC", "WHITEHORSE_YT", "POND_INLET_NU", "TORONTO_ON", "KAMLOOPS_BC", "EDMONTON_AB")), aes(date, monthMeanTemp, fill = location)) + geom_smooth(method = loess) #, fullrange = TRUE)

ggplot(subset(CanClimateMM, location %in% c("AGASSIZ_BC", "WHITEHORSE_YT", "POND_INLET_NU", "TORONTO_ON", "KAMLOOPS_BC", "EDMONTON_AB")), aes(date, monthMeanTemp, fill = location)) + geom_smooth(method = lm) #, fullrange = TRUE)


#### Leaflet Demos ####

library(tidyr) # gather()
library(dplyr) # filter(), first(), group_by(), ' %>% ' aka the pipe operator.
library(ggplot2) # ggplot(), geom_*()
library(stringr) #
library(maps) #
library(leaflet) # leaflet(), etc.
library(sp) # spDistsN1()
library(rgeos) # 
library(gpclib) # 
library(ggthemes) # 
library(maptools) # 


# Coyote Sightings ----

Coyote <- read.csv(url("https://data.edmonton.ca/api/views/2wg2-7scc/rows.csv"), na.strings = "")
# Get rid of lines with no location data.
Coyote <- Coyote[!is.na(Coyote$Location),]
str(Coyote$Location)

# Turn the column into characters so it's easier to work with.
Coyote$Location <- as.character(Coyote$Location)
# Split the column into a matrix of two columns.
loc <- matrix(unlist(strsplit(Coyote$Location, ", ")), nrow = 620, ncol = 2, byrow = TRUE)
# Add those columns to the dataframe.
Coyote <- data.frame(Coyote, loc[,1], loc[,2])
# Make sure the data frame has the names that we want.
CoyNames <- names(Coyote)
CoyNames[5:6] <- c("Latitude", "Longitude")
names(Coyote) <- CoyNames
# Something turned the columns back into factors... I want characters.
Coyote[,5:6] = apply(Coyote[,5:6], 2, function(x) as.character(x))
# str(Coyote)
# Get rid of the non-numeric material
Coyote$Latitude <- substr(Coyote$Latitude,1,nchar(Coyote$Latitude)-1)
Coyote$Latitude <- substr(Coyote$Latitude,2,nchar(Coyote$Latitude))
Coyote$Longitude <- substr(Coyote$Longitude,1,nchar(Coyote$Longitude)-1)
# Turn them into numeric data.
Coyote[,5:6] <- apply(Coyote[,5:6], 2, function(x) as.numeric(x))

leaflet() %>% 
	setView(lng = -113.504655, lat = 53.546629, zoom = 11) %>%
	addProviderTiles(providers$Hydda.Full) %>%
	addCircles(Coyote$Longitude, lat= Coyote$Latitude, popup=paste(Coyote$Date.Reported, Coyote$Report.Type)) %>%
	addMarkers(lng= -113.504655, lat= 53.546629, popup="MacEwan University")

# YEG Property Assessments ----

yeg_property <- read.csv(url("https://data.edmonton.ca/api/views/q7d6-ambg/rows.csv"))
head(yeg_property, 5)[,2:10]

yeg_property$DIST <- spDistsN1(matrix(c(yeg_property$Longitude, yeg_property$Latitude), ncol = 2), matrix(c(-113.504655, 53.546629), ncol = 2), longlat = TRUE)

# Get rid of the $ sign.
yeg_property$Assessed.Value <- gsub("\\$", "", yeg_property$Assessed.Value)
# Change to numeric data
yeg_property$Assessed.Value <- as.numeric(yeg_property$Assessed.Value)
# yeg_property$Assessed.Value <- as.numeric(gsub("\\$", "", yeg_property$Assessed.Value)) # Could be done in one line.

yeg_property <- yeg_property %>%
	filter(Assessment.Class == "Residential", Assessed.Value < 2000000 & Assessed.Value > 50000)

yeg_prop_strath <- yeg_property %>% 
	filter(Neighbourhood == "STRATHCONA")
# yeg_prop_skyrattler <- yeg_property %>%
# 	filter(Neighbourhood == "SKYRATTLER")

# levels(yeg_prop_strath$Street.Name)[levels(yeg_prop_strath$Street.Name) %in% c("83 AVNUE NW", "83 AVE NW")] <- "83 AVENUE NW"

# ggplot(yeg_prop_strath, aes(x = DIST, y = Assessed.Value)) + geom_point(aes(colour = Street.Name), alpha = .4) + geom_smooth(method = "lm") + scale_y_continuous("Assessement") + scale_x_continuous("Distance from MacEwan")
# Note that 'alpha = .4' makes the points more transparent.

leaflet() %>% 
	setView(lng = -113.504655, lat = 53.546629, zoom = 12) %>%
	addProviderTiles(providers$OpenStreetMap.Mapnik) %>%  # Add map tiles
	addCircles(lng = yeg_prop_strath$Longitude, lat = yeg_prop_strath$Latitude, popup = paste( as.character(yeg_prop_strath$House.Number), yeg_prop_strath$Street.Name, "$", as.character(yeg_prop_strath$Assessed.Value))) %>% 
	addMarkers(lng = -113.504655, lat = 53.546629, popup = "MacEwan University")

# leaflet() %>% 
# 	setView(lng = -113.504655, lat = 53.546629, zoom = 12) %>%
# 	addProviderTiles(providers$OpenStreetMap.Mapnik) %>%  # Add map tiles
# 	addCircles(lng = yeg_prop_skyrattler$Longitude, lat = yeg_prop_skyrattler$Latitude, popup = paste( as.character(yeg_prop_skyrattler$House.Number), yeg_prop_skyrattler$Street.Name, "$", as.character(yeg_prop_skyrattler$Assessed.Value))) %>% 
# 	addMarkers(lng = -113.504655, lat = 53.546629, popup = "MacEwan University")

# Choropleth Maps ----

yeg_ward <- readShapeSpatial("/Users/Brian/Dropbox/db documents/HomeR Practice/YEGEPLOpenData/YEGNeighbourhoodBoundaries/geo_export_49e23c74-e6d8-4415-b444-0e02f68ecfda.shp")
yeg_hood <- readShapeSpatial("/Users/Brian/Dropbox/db documents/HomeR Practice/YEGEPLOpenData/YEGNeighbourhoodBoundaries/geo_export_335c0676-dc33-47d1-a816-a8b8b5e3013c.shp")
# VERIFY IT LOADED PROPERLY
plot(yeg_hood)
plot(yeg_ward)

yeg_ward <- fortify(yeg_ward, region = "name")
yeg_hood <- fortify(yeg_hood, region = "name")
yeg_hood$id <- toupper(yeg_hood$id)
yeg_ward$id <- gsub(" 0", " ", yeg_ward$id) 

yeg_transport <- read.csv(url("https://data.edmonton.ca/api/views/9f7k-3qk6/rows.csv"))

yeg_transport <- yeg_transport[,-c(10)]
# I'm going to create ratios of pedestrians and cyclists.
yeg_transport <- mutate(yeg_transport, DENOM = yeg_transport[,4] + yeg_transport[,5] + yeg_transport[,6] + yeg_transport[,7] + yeg_transport[,8] + yeg_transport[,9])
yeg_transport <- mutate(yeg_transport, WalkRatio = WALK/DENOM)
yeg_transport <- mutate(yeg_transport, BikeRatio = BICYCLE/DENOM)
# Neighbourhoods with no responses just get 0s.
yeg_transport$WalkRatio[is.nan(yeg_transport$WalkRatio)] <- 0
yeg_transport$BikeRatio[is.nan(yeg_transport$BikeRatio)] <- 0

# Walkers
ggplot() + geom_map(data = yeg_transport, aes(map_id = NEIGHBOURHOOD_NAME, fill = WalkRatio), map = yeg_hood) + expand_limits(x = yeg_hood$long, y = yeg_hood$lat) + scale_fill_gradient(low = "antiquewhite", high = "darkred") + geom_polygon(data=yeg_hood, aes(x = yeg_hood$long, y = yeg_hood$lat, group = group), colour='black', fill=NA) + ggtitle("Walkers by Neighbourhood")

# Cyclists
ggplot() + geom_map(data = yeg_transport, aes(map_id = NEIGHBOURHOOD_NAME, fill = BikeRatio), map = yeg_hood) + expand_limits(x = yeg_hood$long, y = yeg_hood$lat) + scale_fill_gradient(low = "antiquewhite", high = "darkred") + geom_polygon(data=yeg_hood, aes(x = yeg_hood$long, y = yeg_hood$lat, group = group), colour='black', fill=NA) + ggtitle("Cyclists by Neighbourhood")

